package test0531;

public class Test04 {

	public static void main(String[] args) {
		
		 
		int i = 97;
		
		do { 
			System.out.println((char)i);
			++i;
		} while(i <= 122);

	}

}
